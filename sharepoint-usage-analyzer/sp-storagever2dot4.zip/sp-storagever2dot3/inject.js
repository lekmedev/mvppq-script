// inject.js
(function () {
    'use strict';

    // Tránh inject đè nhiều lần nếu script bị kích hoạt lại
    if (window.__GX_FETCH_INJECTED__) return;
    window.__GX_FETCH_INJECTED__ = true;

    const originalFetch = window.fetch.bind(window);

    window.fetch = async function (...args) {
        const [url, options = {}] = args;
        
        // Chỉ xử lý nếu URL hợp lệ và thuộc Microsoft Graph
        if (typeof url === "string" && url.includes("graph.microsoft.com")) {
            
            // Bỏ qua các request $batch để tránh loop bẫy token vô tận
            if (!url.includes("/$batch")) {
                const headers = options.headers;
                let auth = null;

                // Trích xuất Authorization Header chính xác theo các kiểu dữ liệu
                if (headers instanceof Headers) {
                    auth = headers.get("authorization") || headers.get("Authorization");
                } else if (headers && typeof headers === "object") {
                    auth = headers.authorization || headers.Authorization;
                }

                // Nếu tìm thấy Token, gửi ngay về môi trường Isolated (content.js)
                if (auth) {
                    const token = auth.replace(/^Bearer\s+/i, "").trim();
                    if (token) {
                        window.dispatchEvent(new CustomEvent("GX_TOKEN_CAPTURED", { detail: token }));
                    }
                }
            }
        }

        // Thực thi và trả về kết quả fetch gốc một cách chuẩn xác
        return originalFetch(...args);
    };
})();