'use strict';

// Thực hiện nhúng mã core (inject.js) trực tiếp vào môi trường execution chính của trang web
try {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('inject.js');
    script.onload = function() {
        this.remove(); // Xóa tag sau khi chạy xong để làm sạch DOM
    };
    (document.head || document.documentElement).appendChild(script);
} catch (e) {
    console.error("Graph Explorer Toolkit: Lỗi nạp thành phần mở rộng.", e);
}