(function () {
    'use strict';
    const originalFetch = window.fetch;
    window.fetch = async function (...args) {
        const url = args[0];
        const options = args[1] || {};
        let headers = options.headers;
        let auth = null;

        if (headers instanceof Headers) {
            auth = headers.get("authorization") || headers.get("Authorization");
        } else if (headers && typeof headers === "object") {
            auth = headers.authorization || headers.Authorization;
        }

        if (auth && typeof url === 'string' && url.includes("graph.microsoft.com")) {
            const token = auth.replace(/^Bearer\s+/i, '');
            // Gửi Token bắt được qua content.js
            window.postMessage({ type: "SP_ANALYZER_TOKEN", token: token }, "*");
        }

        return originalFetch.apply(this, args);
    };
})();