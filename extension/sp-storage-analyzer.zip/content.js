(function () {
    'use strict';

    const DEFAULT_SITE_URL = "https://accor.sharepoint.com/sites/HB4V5_SPOF";

    let globalToken = null;
    let lastDriveSizes = [];
    let lastTotalGb = 0;
    let currentStatus = "Chờ quét...";
    let scanTimestamp = "";

    // Tiêm inject.js trực tiếp vào trang web để bypass qua cơ chế Sandbox của Chrome
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('inject.js');
    (document.head || document.documentElement).appendChild(script);
    script.onload = () => script.remove();

    // Nhận Token từ tệp inject.js gửi lên
    window.addEventListener("message", function (event) {
        if (event.data && event.data.type === "SP_ANALYZER_TOKEN") {
            globalToken = event.data.token;
        }
    });

    function getFormattedDateTime() {
        const now = new Date();
        const pad = (num) => String(num).padStart(2, '0');
        return `${pad(now.getHours())}:${pad(now.getMinutes())} ${pad(now.getDate())}/${pad(now.getMonth() + 1)}`;
    }

    async function resolveSiteId(siteUrl, headers) {
        try {
            const url = new URL(siteUrl);
            const hostname = url.hostname;
            const path = url.pathname.replace(/\/$/, "");
            const graphUrl = `https://graph.microsoft.com/v1.0/sites/${hostname}:${path}`;

            const res = await fetch(graphUrl, { headers });
            if (!res.ok) throw new Error("Không tìm thấy Site-ID.");

            return await res.json();
        } catch (e) {
            throw new Error("Something went wrong.");
        }
    }

    async function startAnalyzing(panel, miniBar) {
        const loadingEl = panel.querySelector("#sp-analyzer-loading");
        const loadingText = panel.querySelector("#sp-analyzer-loading-text");
        const resultEl = panel.querySelector("#sp-analyzer-result");
        const footerEl = panel.querySelector("#sp-analyzer-footer");

        loadingEl.style.display = "flex";
        resultEl.innerHTML = "";
        footerEl.style.display = "none";
        lastDriveSizes = [];
        scanTimestamp = "";

        const updateStatus = (text) => {
            loadingText.textContent = text;
            currentStatus = text;
            const miniStatusEl = miniBar.querySelector(".sp-mini-status");
            if (miniStatusEl) miniStatusEl.textContent = text;
        };

        if (!globalToken) {
            updateStatus("Đang kết nối Microsoft Graph...");
            try { await fetch("https://graph.microsoft.com/v1.0/me"); } catch (e) {}
        }

        if (!globalToken) {
            loadingEl.style.display = "none";
            resultEl.innerHTML = `
                <div class="sp-error">
                    <div class="sp-error-icon">⚠️</div>
                    <div>
                        <div class="sp-error-title">Yêu cầu đăng nhập</div>
                        <div class="sp-error-desc">Vui lòng bấm nút "Access token" hoặc chạy thử 1 truy vấn bất kỳ trên Graph Explorer để cấp quyền cho tool hoạt động.</div>
                    </div>
                </div>`;
            updateStatus("Lỗi: Chưa có quyền truy cập");
            return;
        }

        const headers = { "Authorization": `Bearer ${globalToken}` };

        try {
            // Đọc cấu hình từ Chrome Storage API
            const storageData = await chrome.storage.local.get("sp_site_url");
            const siteUrl = storageData.sp_site_url || DEFAULT_SITE_URL;

            updateStatus(`Đang quét: ${siteUrl}...`);
            const site = await resolveSiteId(siteUrl, headers);
            const siteId = site.id;

            const drivesUrl = `https://graph.microsoft.com/v1.0/sites/${siteId}/drives?$select=name,id`;
            const drivesResponse = await fetch(drivesUrl, { headers });

            if (!drivesResponse.ok) {
                throw new Error("Token hết hạn hoặc tài khoản không có quyền trên Site này.");
            }

            const drivesData = await drivesResponse.json();
            const drives = (drivesData.value || []).filter(d => !/^_\$/.test(d.name));

            let driveSizes = [];
            let totalBytes = 0;

            for (let i = 0; i < drives.length; i++) {
                const d = drives[i];
                updateStatus(`Quét (${i + 1}/${drives.length}): ${d.name}`);

                try {
                    let used = 0;
                    let url = `https://graph.microsoft.com/v1.0/drives/${d.id}/root/children?$select=name,size,folder&$top=200`;

                    while (url) {
                        const rRes = await fetch(url, { headers });
                        if (!rRes.ok) break;

                        const r = await rRes.json();
                        const items = r.value || [];

                        for (const item of items) {
                            if (/^_\$.*\$_$/.test(item.name) || /^_\$./.test(item.name)) continue;
                            used += item.size || 0;
                        }
                        url = r["@odata.nextLink"] || null;
                    }

                    if (used > 0) {
                        const gb = used / Math.pow(1024, 3);
                        driveSizes.push({ name: d.name, gb: gb });
                        totalBytes += used;
                    }
                } catch (err) {
                    console.error("Lỗi bỏ qua ổ đĩa: " + d.name, err);
                }
            }

            lastDriveSizes = driveSizes;
            lastTotalGb = totalBytes / Math.pow(1024, 3);
            scanTimestamp = getFormattedDateTime();

            loadingEl.style.display = "none";
            renderModernList(resultEl);

            footerEl.style.display = "flex";
            footerEl.querySelector("#sp-total-value").textContent = `${lastTotalGb.toFixed(2)} GB`;
            updateStatus("Đã quét xong!");

        } catch (error) {
            loadingEl.style.display = "none";
            resultEl.innerHTML = `
                <div class="sp-error">
                    <div class="sp-error-icon">❌</div>
                    <div>
                        <div class="sp-error-title">Something went wrong</div>
                        <div class="sp-error-desc">${error.message}</div>
                    </div>
                </div>`;
            updateStatus("Lỗi kết nối dữ liệu");
        }
    }

    function renderModernList(container) {
        const visualSorted = [...lastDriveSizes].sort((a, b) => b.gb - a.gb);
        let html = `<div class="sp-list-container">`;
        visualSorted.forEach(item => {
            html += `
                <div class="sp-card-row">
                    <div class="sp-card-info">
                        <div class="sp-drive-icon">📁</div>
                        <div class="sp-drive-name" title="${item.name}">${item.name}</div>
                    </div>
                    <div class="sp-badge-size">${item.gb.toFixed(2)} GB</div>
                </div>
            `;
        });
        html += `</div>`;
        container.innerHTML = html;
    }

    function copyResultsToClipboard(panel) {
        if (!lastDriveSizes.length) return;

        const excelSorted = [...lastDriveSizes].sort((a, b) => a.name.localeCompare(b.name, 'vi'));
        let text = `Scanned At: ${scanTimestamp}\n`;
        text += "Tên Drive\tDung lượng (GB)\n";

        excelSorted.forEach(item => {
            text += `${item.name}\t${item.gb.toFixed(2)}\n`;
        });

        text += `TỔNG CỘNG\t${lastTotalGb.toFixed(2)}\n`;

        navigator.clipboard.writeText(text).then(() => {
            const btn = panel.querySelector("#sp-copy-btn");
            const original = btn.innerHTML;

            btn.innerHTML = "✅ Đã copy (Sắp xếp A-Z)!";
            btn.classList.add("sp-copy-success");

            setTimeout(() => {
                btn.innerHTML = original;
                btn.classList.remove("sp-copy-success");
            }, 2500);
        }).catch(err => {
            console.error("Lỗi clipboard:", err);
            alert("Không thể thực hiện copy.");
        });
    }

    async function createCustomUI() {
        if (document.getElementById("custom-sharepoint-btn")) return;

        const sourceBtn = [...document.querySelectorAll("button")].find(btn => {
            const text = (btn.textContent || btn.innerText || "").trim();
            return text.toLowerCase().includes("access token");
        });

        if (!sourceBtn) return;

        // 1. Nút cấu hình ⚙
        const settingBtn = document.createElement("button");
        settingBtn.id = "custom-sharepoint-setting";
        settingBtn.innerHTML = "⚙";
        settingBtn.title = "Cấu hình Site URL";
        settingBtn.className = sourceBtn.className;

        // 2. Nút khởi chạy chính
        const customBtn = document.createElement("button");
        customBtn.id = "custom-sharepoint-btn";
        customBtn.className = sourceBtn.className;
        customBtn.innerHTML = `
            <span style="display:flex;align-items:center;gap:6px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"></path><path d="M22 12A10 10 0 0 0 12 2v10z"></path></svg>
                <span>Tính Dung Lượng SP</span>
            </span>
        `;

        sourceBtn.insertAdjacentElement("afterend", settingBtn);
        sourceBtn.insertAdjacentElement("afterend", customBtn);

        // 3. Khởi tạo Panel
        const panel = document.createElement("div");
        panel.id = "sp-analyzer-panel";
        panel.style.cssText = `display:none; position:fixed; bottom:20px; right:20px; width:460px; max-height:560px; background:#fff; z-index:99999; border-radius:8px; overflow:hidden; border:1px solid #eaeaea; box-shadow: 0 10px 25px rgba(0,0,0,0.15);`;
        panel.innerHTML = `
            <div class="sp-panel-header">
                <div class="sp-panel-title">📊 Dung Lượng SharePoint</div>
                <div class="sp-panel-actions"><span class="sp-panel-btn-min" id="minimize-sp-panel" title="Thu nhỏ">—</span></div>
            </div>
            <div class="sp-panel-body">
                <div id="sp-analyzer-loading">
                    <div class="sp-spinner"></div>
                    <span id="sp-analyzer-loading-text">Đang chuẩn bị...</span>
                </div>
                <div id="sp-analyzer-result"></div>
                <div class="sp-panel-footer" id="sp-analyzer-footer">
                    <div><span class="sp-total-label">Tổng cộng:</span> <span class="sp-total-value" id="sp-total-value">0 GB</span></div>
                    <button class="sp-copy-btn" id="sp-copy-btn">📋 Copy Dữ Liệu</button>
                </div>
            </div>
        `;
        document.body.appendChild(panel);

        // 4. Khởi tạo MiniBar
        const miniBar = document.createElement("div");
        miniBar.id = "sp-analyzer-minibar";
        miniBar.style.display = "none";
        miniBar.innerHTML = `<div class="sp-mini-dot"></div><span>Dung lượng SP:</span><span class="sp-mini-status">${currentStatus}</span>`;
        document.body.appendChild(miniBar);

        // SỰ KIỆN NÚT
        customBtn.addEventListener("click", function (e) {
            e.preventDefault();
            panel.style.display = "block";
            miniBar.style.display = "none";
            if (lastDriveSizes.length === 0 && currentStatus.includes("Chờ quét")) {
                startAnalyzing(panel, miniBar);
            }
        });

        settingBtn.addEventListener("click", async (e) => {
            e.preventDefault();
            const storageData = await chrome.storage.local.get("sp_site_url");
            const current = storageData.sp_site_url || DEFAULT_SITE_URL;
            const url = prompt("Nhập URL đầy đủ của Site SharePoint cần quét:", current);

            if (url === null) return; 

            if (!url.trim()) {
                alert("Vui lòng không để trống URL!");
                return;
            }

            await chrome.storage.local.set({ "sp_site_url": url.trim() });

            panel.style.display = "block";
            miniBar.style.display = "none";
            startAnalyzing(panel, miniBar);
        });

        panel.querySelector("#minimize-sp-panel").onclick = () => {
            panel.style.display = "none";
            miniBar.style.display = "flex";
        };

        miniBar.onclick = () => {
            miniBar.style.display = "none";
            panel.style.display = "block";
        };

        panel.querySelector("#sp-copy-btn").onclick = () => {
            copyResultsToClipboard(panel);
        };
    }

    const observer = new MutationObserver(() => createCustomUI());
    observer.observe(document.documentElement, { childList: true, subtree: true });
})();